<?php get_header(); ?>
	<div id="container">
		<article id="content" class="ignition_project">
			<?php get_template_part( 'loop', 'project' ); ?>
		</article>
		<div class="clear"></div>
	</div>
<?php get_footer(); ?>